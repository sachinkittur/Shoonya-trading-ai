from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .api import auth, bot, news, admin
from .core.scheduler import schedule_square_off
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from .core.ws_broadcast import WebSocketManager

app = FastAPI(title="Shoonya Trader - Complete")
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

app.include_router(auth.router, prefix='/auth')
app.include_router(bot.router, prefix='/bot')
app.include_router(news.router, prefix='/news')
app.include_router(admin.router, prefix='/admin')

ws_manager = WebSocketManager()
app.state.ws_manager = ws_manager

@app.websocket('/ws/orders')
async def ws_orders(ws: WebSocket, user_id: int):
    await ws.accept()
    await ws_manager.connect(user_id, ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        await ws_manager.disconnect(user_id, ws)

scheduler = AsyncIOScheduler(timezone='Asia/Kolkata')
schedule_square_off(scheduler, app)

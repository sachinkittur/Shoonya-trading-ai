import sqlite3, os, threading, json
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'demo.db')
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
_lock = threading.Lock()
def init_db():
    with _lock:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, mode TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS balances (user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 100000)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, order_id TEXT, symbol TEXT, side TEXT, qty INTEGER, price REAL, status TEXT, timestamp INTEGER, source TEXT)""")
        cur.execute("""CREATE TABLE IF NOT EXISTS bot_configs (user_id INTEGER PRIMARY KEY, config_json TEXT, score REAL DEFAULT 0.0)""")
        conn.commit(); conn.close()
class DB:
    def __init__(self): init_db()
    def _conn(self): return sqlite3.connect(DB_PATH)
    def create_user_if_not_exists(self, username, mode):
        with _lock:
            conn = self._conn(); cur = conn.cursor()
            cur.execute('SELECT id FROM users WHERE username=?', (username,))
            r = cur.fetchone()
            if r: uid = r[0]
            else:
                cur.execute('INSERT INTO users(username,mode) VALUES(?,?)', (username,mode))
                uid = cur.lastrowid
                cur.execute('INSERT OR REPLACE INTO balances(user_id,balance) VALUES(?,?)', (uid,100000.0))
                conn.commit()
            conn.close()
            return {'id': uid, 'username': username}
    def get_balance(self, user_id):
        conn = self._conn(); cur = conn.cursor()
        cur.execute('SELECT balance FROM balances WHERE user_id=?', (user_id,))
        r = cur.fetchone(); conn.close()
        return float(r[0]) if r else 0.0
    def insert_order(self, order, user_id=0):
        conn = self._conn(); cur = conn.cursor()
        cur.execute('INSERT INTO orders(user_id,order_id,symbol,side,qty,price,status,timestamp,source) VALUES(?,?,?,?,?,?,?,?,?)',
                    (user_id, order.get('order_id'), order.get('symbol'), order.get('side'), order.get('qty'), order.get('price'), order.get('status'), order.get('timestamp'), order.get('source','bot')))
        conn.commit(); conn.close()
    def save_bot_config(self, user_id, cfg: dict, score: float):
        conn = self._conn(); cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO bot_configs(user_id,config_json,score) VALUES(?,?,?)', (user_id, json.dumps(cfg), float(score)))
        conn.commit(); conn.close()
    def load_bot_config(self, user_id):
        conn = self._conn(); cur = conn.cursor()
        cur.execute('SELECT config_json, score FROM bot_configs WHERE user_id=?', (user_id,))
        r = cur.fetchone(); conn.close()
        if not r: return (None, 0.0)
        return (json.loads(r[0]), float(r[1]))
_db = None
def get_db():
    global _db
    if _db is None: _db = DB()
    return _db

import os, time, random
import pandas as pd, numpy as np
from dotenv import load_dotenv
load_dotenv()
class BaseClient:
    def login(self): raise NotImplementedError
    def place_order(self,symbol,qty,side,order_type,price=None): raise NotImplementedError
    def get_market_data(self,symbol,timeframe='1m',limit=200): raise NotImplementedError
    def get_open_interest(self,symbol): return 10000
class MockShoonyaClient(BaseClient):
    def __init__(self): self._id=1; self.balance=100000.0
    def login(self): return {'status':'ok','mode':'demo'}
    def place_order(self,symbol,qty,side,order_type,price=None):
        oid=f'MOCK-{self._id}'; self._id+=1; ts=int(time.time())
        order={'order_id':oid,'symbol':symbol,'qty':qty,'side':side,'price':price or 0.0,'status':'filled','timestamp':ts}
        return order
    def get_market_data(self,symbol,timeframe='1m',limit=200):
        idx = pd.date_range(end=pd.Timestamp.now(), periods=limit, freq='T')
        price = 1000 + np.cumsum(np.random.randn(limit))
        df = pd.DataFrame({'open':price,'high':price+abs(np.random.randn(limit)),'low':price-abs(np.random.randn(limit)),'close':price}, index=idx)
        return df
class ShoonyaLiveClient(BaseClient):
    def __init__(self, userid, password, appkey, appsecret, totp):
        self.userid=userid; self.password=password; self.appkey=appkey; self.appsecret=appsecret; self.totp=totp; self.client=None; self._connected=False
    @classmethod
    def from_env(cls):
        return cls(os.getenv('SHOONYA_USERID'), os.getenv('SHOONYA_PASSWORD'), os.getenv('SHOONYA_APPKEY'), os.getenv('SHOONYA_APPSECRET'), os.getenv('SHOONYA_TOTP'))
    def login(self):
        try:
            from NorenRestApiPy import NorenApi
            import pyotp
        except Exception as e:
            raise RuntimeError('Install NorenRestApiPy and pyotp to use live mode') from e
        self.client = NorenApi()
        otp = pyotp.TOTP(self.totp).now()
        ret = self.client.login(userid=self.userid, password=self.password, twoFA=otp, vendor_code=self.appkey, api_secret=self.appsecret, imei='python-api')
        self._connected=True; return ret
    def place_order(self,symbol,qty,side,order_type,price=None):
        if not self._connected: self.login()
        params={'tradingsymbol':symbol,'quantity':qty,'price':price or 0,'order_type':order_type,'transaction_type':'BUY' if side=='CALL' else 'SELL'}
        res = self.client.place_order(params)
        return {'order_id': res.get('orderid', 'LIVE-UNK'), 'symbol': symbol, 'qty': qty, 'side': side, 'price': price or 0.0, 'status':'submitted', 'timestamp': int(time.time())}
    def get_market_data(self,symbol,timeframe='1m',limit=200):
        if not self._connected: self.login()
        try:
            df = self.client.get_historical_data(symbol, timeframe=timeframe, limit=limit)
            return df
        except Exception:
            idx = pd.date_range(end=pd.Timestamp.now(), periods=limit, freq='T')
            price = 1000 + np.cumsum(np.random.randn(limit))
            import pandas as pd
            df = pd.DataFrame({'open':price,'high':price+abs(np.random.randn(limit)),'low':price-abs(np.random.randn(limit)),'close':price}, index=idx)
            return df

import json
from fastapi import WebSocket
class WebSocketManager:
    def __init__(self):
        self._conns = {}
    async def connect(self, user_id:int, ws:WebSocket):
        conns = self._conns.setdefault(user_id, set())
        conns.add(ws)
    async def disconnect(self, user_id:int, ws:WebSocket):
        conns = self._conns.get(user_id, set())
        if ws in conns: conns.remove(ws)
    async def send_user(self, user_id:int, message:dict):
        conns = self._conns.get(user_id, set())
        for ws in list(conns):
            try:
                await ws.send_text(json.dumps(message))
            except: pass

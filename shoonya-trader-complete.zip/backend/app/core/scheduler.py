from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
def schedule_square_off(scheduler, app):
    def _job(): print('[scheduler] square-off job triggered')
    scheduler.add_job(_job, CronTrigger(hour=15, minute=15))
    scheduler.start()

import os, requests
from transformers import pipeline
try:
    model = pipeline('sentiment-analysis', model='ProsusAI/finbert')
except Exception:
    model = None
NEWSAPI_KEY = os.getenv('NEWSAPI_KEY', '')
def fetch_latest_news(symbol='NIFTY'):
    if not NEWSAPI_KEY:
        return [{'title':'Demo: markets steady','description':'No breaking news'}]
    url=f'https://newsapi.org/v2/everything?q={symbol}&sortBy=publishedAt&apiKey={NEWSAPI_KEY}'
    r=requests.get(url).json(); articles=r.get('articles',[])[:5]
    return [{'title':a.get('title'),'description':a.get('description')} for a in articles]
def analyze_news(articles):
    if not model:
        out=[]
        for a in articles: out.append({'title':a.get('title'),'desc':a.get('description'),'sentiment':'NEUTRAL','score':0.0})
        return out
    scored=[]
    for a in articles:
        text=(a.get('title') or '')+' '+(a.get('description') or '')
        res=model(text[:512])[0]
        scored.append({'title':a.get('title'),'desc':a.get('description'),'sentiment':res['label'].lower(),'score':res['score']})
    return scored
def get_news_sentiment(symbol='NIFTY'):
    arts=fetch_latest_news(symbol); analyzed=analyze_news(arts)
    agg=0.0
    for a in analyzed:
        if a['sentiment']=='positive': agg+=a['score']
        elif a['sentiment']=='negative': agg-=a['score']
    return {'symbol':symbol,'score':round(agg,4),'articles':analyzed}

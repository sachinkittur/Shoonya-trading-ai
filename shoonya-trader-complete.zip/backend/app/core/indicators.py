import numpy as np, pandas as pd
def ema(series, period): return series.ewm(span=period, adjust=False).mean()
def rsi(series, period=14):
    delta = series.diff(); up = delta.clip(lower=0).fillna(0); down = -1*delta.clip(upper=0).fillna(0)
    ma_up = up.ewm(alpha=1/period, adjust=False).mean(); ma_down = down.ewm(alpha=1/period, adjust=False).mean()
    rs = ma_up/(ma_down+1e-9); return 100 - (100/(1+rs))
def _atr(df, period=10):
    high, low, close = df['high'], df['low'], df['close']
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/period, adjust=False).mean()
def supertrend(df, period=10, multiplier=3.0):
    high, low, close = df['high'], df['low'], df['close']; hl2 = (high+low)/2; atr = _atr(df, period)
    upper = hl2 + multiplier*atr; lower = hl2 - multiplier*atr; final_u=upper.copy(); final_l=lower.copy()
    trend = np.ones(len(df))
    for i in range(1,len(df)):
        if close.iat[i] > final_u.iat[i-1]: trend[i]=1
        elif close.iat[i] < final_l.iat[i-1]: trend[i]=-1
        else:
            trend[i]=trend[i-1]
            if trend[i]==1 and lower.iat[i] < final_l.iat[i-1]: final_l.iat[i]=final_l.iat[i-1]
            if trend[i]==-1 and upper.iat[i] > final_u.iat[i-1]: final_u.iat[i]=final_u.iat[i-1]
    return pd.Series(trend, index=df.index)

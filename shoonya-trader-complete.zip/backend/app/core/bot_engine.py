import asyncio, random
from datetime import datetime, time as dtime, timedelta
import zoneinfo, time as timelib
from .indicators import ema, rsi, supertrend
from .db import get_db
IST = zoneinfo.ZoneInfo('Asia/Kolkata')
def ist_now(): return datetime.now(IST)
def is_expiry_day(): return ist_now().weekday()==3
class Position:
    def __init__(self, side, qty, entry_price, opened_at):
        self.side=side; self.qty=qty; self.entry_price=float(entry_price or 0.0); self.opened_at=opened_at; self.closed_at=None; self.exit_price=None
    def is_open(self): return self.closed_at is None
    def pnl_pct(self,last): 
        if self.entry_price==0: return 0.0
        change=(last-self.entry_price)/self.entry_price
        return change if self.side=='CALL' else -change
class TradingBot:
    def __init__(self, client, symbol, config, user_id, app=None):
        from .db import get_db as _get_db
        saved_cfg, score = _get_db().load_bot_config(user_id)
        EPS = float(config.get('epsilon_explore',0.1))
        if saved_cfg and random.random()>EPS: self.config={**saved_cfg}
        else: self.config=config
        self.client=client; self.symbol=symbol; self.user_id=user_id; self._running=False; self._task=None; self.db=get_db(); self.position=None; self._cooldown_until=None; self.daily_loss=0.0
    def start_background(self):
        if self._task and not self._task.done(): return
        self._running=True; self._task=asyncio.create_task(self._run_loop())
    async def _run_loop(self):
        while self._running:
            try:
                now=ist_now()
                # respect session
                start=self._parse_hm(self.config.get('session_start','09:15')); end=self._parse_hm(self.config.get('session_end','15:15'))
                if not (start <= now.time() <= end):
                    await asyncio.sleep(5); continue
                # cooldown
                if self._cooldown_until and now < self._cooldown_until:
                    await asyncio.sleep(self.config.get('poll_interval',5)); continue
                df=self.client.get_market_data(self.symbol, timeframe='1m', limit=200)
                df=df.rename(columns=lambda c:c.lower())
                df['ema_fast']=ema(df['close'], self.config.get('ema_fast',9))
                df['ema_slow']=ema(df['close'], self.config.get('ema_slow',21))
                df['rsi']=rsi(df['close'], self.config.get('rsi_period',14))
                df['trend']=supertrend(df[['high','low','close']], self.config.get('supertrend_period',10), self.config.get('supertrend_multiplier',3))
                latest=df.iloc[-1]; last_price=float(latest['close'])
                oi=self.client.get_open_interest(self.symbol)
                # news check
                if self.config.get('use_news_filter', False):
                    from .news_analysis import get_news_sentiment
                    news = get_news_sentiment(self.symbol)
                    if self.config.get('auto_exit_on_news', True) and news['score'] <= self.config.get('news_exit_threshold', -0.5):
                        # exit positions immediately
                        if self.position and self.position.is_open():
                            await self._exit_position(reason='news_exit', price=last_price)
                        # cooldown
                        self._cooldown_until = datetime.now(IST) + timedelta(seconds=self.config.get('cooldown_after_news_exit_secs',300))
                        await asyncio.sleep(self.config.get('poll_interval',5)); continue
                # manage open
                if self.position and self.position.is_open():
                    await self._maybe_exit_position(last_price, now)
                # entry logic
                if (not self.position or not self.position.is_open()) and self._within_entry_session(now):
                    decision=None
                    if latest['ema_fast'] > latest['ema_slow'] and latest['rsi'] < self.config.get('rsi_buy_threshold',35) and latest['trend']==1 and oi>self.config.get('min_oi',1000):
                        decision={'side':'CALL','qty':self.config.get('default_qty',1)}
                    elif latest['ema_fast'] < latest['ema_slow'] and latest['rsi'] > self.config.get('rsi_sell_threshold',65) and latest['trend']==-1 and oi>self.config.get('min_oi',1000):
                        decision={'side':'PUT','qty':self.config.get('default_qty',1)}
                    if decision and self._check_fund_limit(decision['qty']):
                        order=self.client.place_order(self.symbol, decision['qty'], decision['side'], order_type='market', price=last_price)
                        self.db.insert_order(order, user_id=self.user_id)
                        self.position=Position(decision['side'], decision['qty'], entry_price=last_price, opened_at=now)
                await asyncio.sleep(self.config.get('poll_interval',5))
            except Exception as e:
                print('Bot error', e); await asyncio.sleep(2)
    async def _maybe_exit_position(self, last_price, now):
        if not self.position or not self.position.is_open(): return
        tp=float(self.config.get('tp_pct',0.003)); sl=float(self.config.get('sl_pct',0.002)); max_hold=int(self.config.get('max_hold_secs',60))
        if is_expiry_day() and self.config.get('expiry_only_scalp',False):
            tp=float(self.config.get('expiry_tp_pct',tp)); sl=float(self.config.get('expiry_sl_pct',sl)); max_hold=int(self.config.get('expiry_max_hold_secs',max_hold))
        pnl=self.position.pnl_pct(last_price); age=(now-self.position.opened_at).total_seconds()
        exit_reason=None
        if pnl>=tp: exit_reason='TP'
        elif pnl<=-sl: exit_reason='SL'
        elif age>=max_hold: exit_reason='TIMEOUT'
        else:
            force=self._parse_hm(self.config.get('force_square_off_time','15:15'))
            if now.time()>=force: exit_reason='SESSION_END'
        if exit_reason:
            await self._exit_position(reason=exit_reason, price=last_price)
    async def _exit_position(self, reason, price):
        exit_side='PUT' if self.position.side=='CALL' else 'CALL'
        order=self.client.place_order(self.symbol, self.position.qty, exit_side, order_type='market', price=price)
        order['source']='exit_'+reason.lower(); self.db.insert_order(order, user_id=self.user_id)
        self.position.exit_price=price; self.position.closed_at=ist_now()
    def _check_fund_limit(self, qty):
        bal=self.db.get_balance(self.user_id); max_trade=self.config.get('max_per_trade',50000)
        return (qty * self.config.get('notional_per_qty',100)) <= min(bal, max_trade)
    def _within_entry_session(self, now):
        start=self._parse_hm(self.config.get('session_start','09:15')); end=self._parse_hm(self.config.get('session_end','15:15'))
        if not (start <= now.time() <= end): return False
        if is_expiry_day() and now.time() > self._parse_hm(self.config.get('expiry_no_new_after','15:05')): return False
        return True
    def _parse_hm(self,s): h,m = s.split(':'); return dtime(int(h),int(m))
    async def stop(self): self._running=False; if self._task: await asyncio.sleep(0.1)
class BotManager:
    def __init__(self): self._bots={}
    def register(self,user_id,bot): self._bots[user_id]=bot
    def get(self,user_id): return self._bots.get(user_id)
    def unregister(self,user_id):
        if user_id in self._bots: del self._bots[user_id]

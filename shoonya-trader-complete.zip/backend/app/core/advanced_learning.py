import os, joblib
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score
MODEL_DIR=os.path.join(os.path.dirname(__file__),'..','models'); os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH=os.path.join(MODEL_DIR,'rf_direction.pkl')
def make_features(df):
    df=df.copy(); df['ret1']=df['close'].pct_change().fillna(0)
    df['ema5']=df['close'].ewm(span=5,adjust=False).mean(); df['ema13']=df['close'].ewm(span=13,adjust=False).mean()
    df['ema_diff']=df['ema5']-df['ema13']; delta=df['close'].diff()
    up=delta.clip(lower=0); down=-1*delta.clip(upper=0)
    rs=up.ewm(alpha=1/14,adjust=False).mean()/(down.ewm(alpha=1/14,adjust=False).mean()+1e-9)
    df['rsi']=100-(100/(1+rs)); df['vol']=df['ret1'].rolling(10).std().fillna(0)
    for lag in (1,2,3): df[f'ret1_lag{lag}']=df['ret1'].shift(lag).fillna(0); df[f'ema_diff_lag{lag}']=df['ema_diff'].shift(lag).fillna(0)
    df=df.dropna(); return df
def prepare_xy(df,horizon=1):
    df=make_features(df); df['target']=(df['close'].shift(-horizon)>df['close']).astype(int); df=df.dropna()
    X=df[['ret1','ema5','ema13','ema_diff','rsi','vol','ret1_lag1','ret1_lag2','ret1_lag3','ema_diff_lag1','ema_diff_lag2','ema_diff_lag3']].values
    y=df['target'].values; return X,y,df
def walk_forward_train(df,iterations=5):
    X,y,df_feat=prepare_xy(df); tscv=TimeSeriesSplit(n_splits=iterations)
    best=None; best_score=-1; scores=[]
    for train_idx,test_idx in tscv.split(X):
        Xtr,Xt=X[train_idx],X[test_idx]; ytr,yt=y[train_idx],y[test_idx]
        model=RandomForestClassifier(n_estimators=100,max_depth=6,n_jobs=-1,random_state=42)
        model.fit(Xtr,ytr); yp=model.predict(Xt); acc=accuracy_score(yt,yp); scores.append(acc)
        if acc>best_score: best_score=acc; best=model
    joblib.dump(best, MODEL_PATH); return {'mean_score':float(sum(scores)/len(scores)),'best_score':float(best_score),'model_path':MODEL_PATH}
def load_model():
    if os.path.exists(MODEL_PATH): return joblib.load(MODEL_PATH)
    return None
def predict_from_model(df_last):
    model=load_model(); 
    if model is None: return None
    X,y,df_feat=prepare_xy(df_last)
    if len(X)==0: return None
    probs=model.predict_proba(X[-1].reshape(1,-1))[0]; return float(probs[1])

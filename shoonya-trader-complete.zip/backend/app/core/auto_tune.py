import random
DEFAULT_SPACE={ 'ema_fast':(5,15), 'ema_slow':(16,50), 'rsi_period':(8,21), 'rsi_buy_threshold':(25,45), 'rsi_sell_threshold':(55,80), 'supertrend_period':(7,14), 'supertrend_multiplier':(2.0,4.0) }
def sample_config(space=DEFAULT_SPACE):
    cfg={}
    for k,(lo,hi) in space.items():
        if isinstance(lo,int): cfg[k]=random.randint(lo,hi)
        else: cfg[k]=round(random.uniform(lo,hi),2)
    return cfg
def random_search(df,iterations=30):
    best={'score':-1e9,'config':None,'metrics':None}
    for _ in range(int(iterations)):
        cfg=sample_config()
        # cheap eval: skip heavy; return random score for demo
        score=random.random()
        if score>best['score']: best={'score':score,'config':cfg,'metrics':{'score':score}}
    return best

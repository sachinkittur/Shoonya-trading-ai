from fastapi import APIRouter
from ..core.news_analysis import get_news_sentiment
router = APIRouter()

@router.get('/sentiment')
async def sentiment(symbol: str = 'NIFTY'):
    return get_news_sentiment(symbol)

from fastapi import APIRouter
from pydantic import BaseModel
from ..core.shoonya_client import MockShoonyaClient, ShoonyaLiveClient
from ..core.bot_engine import TradingBot, BotManager
from ..core.db import get_db, init_db

router = APIRouter()
bot_manager = BotManager()

class BotStartReq(BaseModel):
    user_id: int
    symbol: str
    demo: bool = True
    config: dict = {}

@router.post('/start')
async def start_bot(req: BotStartReq):
    init_db()
    client = MockShoonyaClient() if req.demo else ShoonyaLiveClient.from_env()
    default_cfg = {
        'ema_fast':9,'ema_slow':21,'rsi_period':14,
        'rsi_buy_threshold':35,'rsi_sell_threshold':65,
        'supertrend_period':10,'supertrend_multiplier':3,
        'min_oi':1000,'default_qty':1,'poll_interval':5,'notional_per_qty':100
    }
    cfg = {**default_cfg, **req.config}
    bot = TradingBot(client, req.symbol, cfg, req.user_id, app=None)
    bot_manager.register(req.user_id, bot)
    bot.start_background()
    return {'status':'started'}

class BotStopReq(BaseModel):
    user_id: int

@router.post('/stop')
async def stop_bot(req: BotStopReq):
    bot = bot_manager.get(req.user_id)
    if not bot:
        return {'status':'no_bot'}
    await bot.stop()
    bot_manager.unregister(req.user_id)
    return {'status':'stopped'}

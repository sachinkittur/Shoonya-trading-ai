from fastapi import APIRouter
from pydantic import BaseModel
from ..core.db import get_db, init_db

router = APIRouter()

class LoginReq(BaseModel):
    username: str
    mode: str = 'demo'

@router.post('/login')
async def login(req: LoginReq):
    init_db()
    user = get_db().create_user_if_not_exists(req.username, req.mode)
    return {'status':'ok','user_id': user['id'],'mode': req.mode}

from fastapi import APIRouter
from pydantic import BaseModel
from ..core.advanced_learning import walk_forward_train, load_model
from ..core.auto_tune import random_search
from ..core.shoonya_client import MockShoonyaClient

router = APIRouter()

class TrainReq(BaseModel):
    user_id: int
    symbol: str = 'NIFTY-TEST'
    iterations: int = 5

@router.post('/train_model')
async def train_model(req: TrainReq):
    client = MockShoonyaClient()
    df = client.get_market_data(req.symbol, timeframe='1m', limit=2000)
    res = walk_forward_train(df, iterations=req.iterations)
    return {'status':'ok','result':res}

class AutoTuneReq(BaseModel):
    user_id: int
    symbol: str = 'NIFTY-TEST'
    iterations: int = 30

@router.post('/autotune')
async def autotune(req: AutoTuneReq):
    client = MockShoonyaClient()
    df = client.get_market_data(req.symbol, timeframe='1m', limit=1500)
    best = random_search(df, iterations=req.iterations)
    return {'status':'ok','best': best}

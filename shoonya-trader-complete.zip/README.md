Shoonya Trader - Complete package
-------------------------------
This package contains a backend (FastAPI) and a minimal frontend (not included in this ZIP to reduce size).
It supports Demo mode (MockShoonyaClient) and Live mode (ShoonyaLiveClient wrapper for NorenRestApiPy).

Steps to run backend:
1. cd backend
2. python3 -m venv venv && source venv/bin/activate
3. pip install -r requirements.txt
4. (optional) pip install NorenRestApiPy pyotp
5. copy .env.example to .env and fill keys if using real mode
6. uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
